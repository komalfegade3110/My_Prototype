"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Plus, X, Zap, Loader2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { AiSuggestions } from "@/components/ai-suggestions"
import { useCreatorToken } from "@/hooks/use-creator-token"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

export function CreatePollForm() {
  const router = useRouter()
  const creatorToken = useCreatorToken()
  const [question, setQuestion] = useState("")
  const [options, setOptions] = useState(["", ""])
  const [isAnonymous, setIsAnonymous] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showAi, setShowAi] = useState(true)
  const [justFilled, setJustFilled] = useState(false)

  const addOption = () => {
    if (options.length < 10) {
      setOptions([...options, ""])
    }
  }

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index))
    }
  }

  const updateOption = (index: number, value: string) => {
    const updated = [...options]
    updated[index] = value
    setOptions(updated)
  }

  const handleAiSelect = (q: string, opts: string[]) => {
    setQuestion(q)
    setOptions(opts)
    setShowAi(false)
    setJustFilled(true)
    toast.success("Template applied! Customize it or create as-is.")
    setTimeout(() => setJustFilled(false), 600)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!question.trim()) {
      toast.error("Please enter a question")
      return
    }

    const filledOptions = options.filter((o) => o.trim())
    if (filledOptions.length < 2) {
      toast.error("Please add at least 2 options")
      return
    }

    if (!creatorToken) return

    setIsSubmitting(true)
    try {
      const res = await fetch("/api/polls", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: question.trim(),
          options: filledOptions,
          creatorToken,
          isAnonymous,
        }),
      })

      if (!res.ok) {
        const data = await res.json()
        toast.error(data.error || "Failed to create poll")
        return
      }

      const poll = await res.json()
      toast.success("Poll created successfully!")
      router.push(`/poll/${poll.id}`)
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="mx-auto max-w-xl space-y-6">
      {/* AI Suggestions */}
      {showAi ? (
        <div className="animate-fade-in-up">
          <AiSuggestions onSelectQuestion={handleAiSelect} />
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setShowAi(true)}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border bg-card/50 p-3 text-sm text-muted-foreground transition-all hover:border-primary/30 hover:text-foreground"
        >
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          Show AI suggestions
        </button>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className={cn(
          "rounded-2xl border border-border bg-card p-6 shadow-sm transition-all",
          justFilled && "ring-2 ring-primary/20 animate-scale-in"
        )}>
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Create a Poll</h2>
              <p className="text-sm text-muted-foreground">Ask a question, add options, and share.</p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Question */}
            <div className="space-y-2">
              <Label htmlFor="question" className="text-sm font-medium text-foreground">
                Your Question
              </Label>
              <Input
                id="question"
                placeholder="What should we do for the group project?"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="h-12 text-base"
                maxLength={200}
              />
              <p className="text-xs text-muted-foreground">{question.length}/200</p>
            </div>

            {/* Options */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">Options</Label>
              {options.map((option, index) => (
                <div key={index} className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: `${index * 50}ms` }}>
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-secondary text-xs font-medium text-secondary-foreground">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <Input
                    placeholder={`Option ${index + 1}`}
                    value={option}
                    onChange={(e) => updateOption(index, e.target.value)}
                    className="h-11"
                    maxLength={100}
                  />
                  {options.length > 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeOption(index)}
                      className="h-9 w-9 shrink-0 text-muted-foreground hover:text-destructive"
                    >
                      <X className="h-4 w-4" />
                      <span className="sr-only">Remove option</span>
                    </Button>
                  )}
                </div>
              ))}
              {options.length < 10 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addOption}
                  className="w-full border-dashed"
                >
                  <Plus className="mr-1.5 h-4 w-4" />
                  Add Option
                </Button>
              )}
            </div>

            {/* Anonymous Toggle */}
            <div className="flex items-center justify-between rounded-xl border border-border bg-secondary/30 p-4">
              <div>
                <Label htmlFor="anonymous" className="text-sm font-medium text-foreground">
                  Anonymous Voting
                </Label>
                <p className="text-xs text-muted-foreground">Voters remain anonymous</p>
              </div>
              <Switch
                id="anonymous"
                checked={isAnonymous}
                onCheckedChange={setIsAnonymous}
              />
            </div>
          </div>
        </div>

        <Button
          type="submit"
          size="lg"
          disabled={isSubmitting || !creatorToken}
          className="h-12 w-full text-base shadow-lg shadow-primary/20"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" />
              Create Poll
            </>
          )}
        </Button>
      </form>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Sparkles, ArrowRight, RefreshCw, Zap, BookOpen, Calendar, MapPin, Code, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface AiSuggestionsProps {
  onSelectQuestion: (question: string, options: string[]) => void
}

interface Suggestion {
  category: string
  icon: React.ElementType
  question: string
  options: string[]
}

const allSuggestions: Suggestion[] = [
  {
    category: "Study",
    icon: BookOpen,
    question: "Where should our study group meet this week?",
    options: ["University Library", "Campus Cafe", "Online via Zoom", "Someone's apartment"],
  },
  {
    category: "Schedule",
    icon: Calendar,
    question: "What's the best time for our group meeting?",
    options: ["Monday morning", "Wednesday afternoon", "Friday evening", "Weekend"],
  },
  {
    category: "Project",
    icon: Code,
    question: "Which project topic should we pick for the semester?",
    options: ["AI Chatbot", "Mobile App", "Web Platform", "Data Visualization"],
  },
  {
    category: "Event",
    icon: MapPin,
    question: "Where should we host the class get-together?",
    options: ["Campus lawn", "Downtown restaurant", "Bowling alley", "Movie theater"],
  },
  {
    category: "Sprint",
    icon: Zap,
    question: "What should we prioritize this sprint?",
    options: ["Bug fixes", "New feature development", "UI/UX improvements", "Performance optimization"],
  },
  {
    category: "Team",
    icon: Users,
    question: "How should we split the work for the assignment?",
    options: ["By sections", "By skill set", "Pair programming", "Everyone does everything"],
  },
  {
    category: "Study",
    icon: BookOpen,
    question: "Which subject should we focus on for finals prep?",
    options: ["Mathematics", "Computer Science", "Physics", "Literature"],
  },
  {
    category: "Sprint",
    icon: Zap,
    question: "How was the last sprint overall?",
    options: ["Excellent - shipped everything", "Good - minor delays", "Okay - some blockers", "Rough - needs discussion"],
  },
  {
    category: "Event",
    icon: Calendar,
    question: "What activity for our team building day?",
    options: ["Hackathon", "Outdoor adventure", "Board game tournament", "Cooking class"],
  },
  {
    category: "Project",
    icon: Code,
    question: "Which tech stack should we use?",
    options: ["React + Node.js", "Python + Django", "Flutter", "Next.js + Supabase"],
  },
  {
    category: "Team",
    icon: Users,
    question: "What format works best for standup?",
    options: ["In person, 10 min", "Async in Slack", "Video call, 15 min", "Walking standup"],
  },
  {
    category: "Schedule",
    icon: Calendar,
    question: "When should we set the project deadline?",
    options: ["End of this week", "Next Monday", "Two weeks from now", "End of month"],
  },
]

function getRandomSuggestions(count: number): Suggestion[] {
  const shuffled = [...allSuggestions].sort(() => Math.random() - 0.5)
  return shuffled.slice(0, count)
}

export function AiSuggestions({ onSelectQuestion }: AiSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>(() => getRandomSuggestions(4))
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)

  const refreshSuggestions = () => {
    setIsRefreshing(true)
    setSelectedIndex(null)
    setTimeout(() => {
      setSuggestions(getRandomSuggestions(4))
      setIsRefreshing(false)
    }, 400)
  }

  const handleSelect = (suggestion: Suggestion, index: number) => {
    setSelectedIndex(index)
    setTimeout(() => {
      onSelectQuestion(suggestion.question, suggestion.options)
      setSelectedIndex(null)
    }, 300)
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">AI Suggestions</h3>
            <p className="text-xs text-muted-foreground">Pick a template to get started fast</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={refreshSuggestions}
          disabled={isRefreshing}
          className="h-8 text-xs text-muted-foreground hover:text-foreground"
        >
          <RefreshCw className={cn("mr-1 h-3 w-3", isRefreshing && "animate-spin")} />
          Refresh
        </Button>
      </div>

      <div className={cn("grid gap-2 sm:grid-cols-2", isRefreshing && "opacity-40 transition-opacity")}>
        {suggestions.map((suggestion, index) => (
          <button
            key={`${suggestion.question}-${index}`}
            type="button"
            onClick={() => handleSelect(suggestion, index)}
            className={cn(
              "group flex flex-col items-start gap-2 rounded-xl border border-border bg-background p-3.5 text-left transition-all duration-200 hover:border-primary/30 hover:shadow-md hover:shadow-primary/5 hover:-translate-y-0.5",
              selectedIndex === index && "border-primary bg-primary/5 ring-1 ring-primary/20 scale-[0.98]"
            )}
          >
            <div className="flex w-full items-center justify-between">
              <div className="flex items-center gap-2">
                <suggestion.icon className="h-3.5 w-3.5 text-primary" />
                <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                  {suggestion.category}
                </span>
              </div>
              <ArrowRight className="h-3 w-3 text-muted-foreground opacity-0 transition-all group-hover:opacity-100 group-hover:translate-x-0.5" />
            </div>
            <p className="text-sm font-medium leading-snug text-foreground">
              {suggestion.question}
            </p>
            <div className="flex flex-wrap gap-1">
              {suggestion.options.slice(0, 3).map((opt) => (
                <span
                  key={opt}
                  className="rounded-md bg-secondary/80 px-1.5 py-0.5 text-[10px] text-muted-foreground"
                >
                  {opt}
                </span>
              ))}
              {suggestion.options.length > 3 && (
                <span className="rounded-md bg-secondary/80 px-1.5 py-0.5 text-[10px] text-muted-foreground">
                  +{suggestion.options.length - 3}
                </span>
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

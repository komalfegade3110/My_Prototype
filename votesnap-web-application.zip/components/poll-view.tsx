"use client"

import { useState, useEffect, useCallback } from "react"
import { CheckCircle2, Clock, Lock, Users, BarChart3, Loader2, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SharePoll } from "@/components/share-poll"
import { useVoterToken } from "@/hooks/use-creator-token"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface PollOption {
  id: string
  text: string
  votes: number
}

interface PollData {
  id: string
  question: string
  options: PollOption[]
  createdAt: string
  closedAt: string | null
  isAnonymous: boolean
  totalVotes: number
  hasVoted?: boolean
}

const BAR_COLORS = [
  "bg-primary",
  "bg-accent",
  "bg-chart-3",
  "bg-chart-4",
  "bg-chart-5",
  "bg-chart-1",
  "bg-chart-2",
]

export function PollView({ pollId }: { pollId: string }) {
  const voterToken = useVoterToken()
  const [poll, setPoll] = useState<PollData | null>(null)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [hasVoted, setHasVoted] = useState(false)
  const [isVoting, setIsVoting] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPoll = useCallback(async () => {
    if (!voterToken) return
    try {
      const res = await fetch(`/api/polls/${pollId}?voterToken=${voterToken}`)
      if (!res.ok) {
        setError("Poll not found")
        return
      }
      const data = await res.json()
      setPoll(data)
      if (data.hasVoted) {
        setHasVoted(true)
      }
    } catch {
      setError("Failed to load poll")
    } finally {
      setLoading(false)
    }
  }, [pollId, voterToken])

  useEffect(() => {
    fetchPoll()
  }, [fetchPoll])

  useEffect(() => {
    if (!voterToken) return
    const interval = setInterval(fetchPoll, 3000)
    return () => clearInterval(interval)
  }, [fetchPoll, voterToken])

  const handleVote = async () => {
    if (!selectedOption || !voterToken) return

    setIsVoting(true)
    try {
      const res = await fetch(`/api/polls/${pollId}/vote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ optionId: selectedOption, voterToken }),
      })

      if (!res.ok) {
        const data = await res.json()
        toast.error(data.error || "Failed to vote")
        return
      }

      const data = await res.json()
      setPoll(data)
      setHasVoted(true)
      toast.success("Vote recorded!")
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsVoting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="relative">
          <div className="h-12 w-12 rounded-full border-2 border-secondary" />
          <div className="absolute inset-0 h-12 w-12 animate-spin rounded-full border-2 border-transparent border-t-primary" />
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Loading poll...</p>
      </div>
    )
  }

  if (error || !poll) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in-up">
        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-destructive/10">
          <Lock className="h-8 w-8 text-destructive" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">{error || "Poll not found"}</h2>
        <p className="mt-2 text-muted-foreground">This poll may have been deleted or doesn{"'"}t exist.</p>
        <Button variant="outline" asChild className="mt-6">
          <Link href="/">
            <ArrowLeft className="mr-1.5 h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </div>
    )
  }

  const isClosed = !!poll.closedAt
  const showResults = hasVoted || isClosed
  const maxVotes = Math.max(...poll.options.map((o) => o.votes), 1)

  return (
    <div className="mx-auto max-w-xl space-y-6 animate-fade-in-up">
      {/* Poll Header */}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {isClosed ? (
              <Badge variant="secondary" className="bg-destructive/10 text-destructive">
                <Lock className="mr-1 h-3 w-3" />
                Closed
              </Badge>
            ) : (
              <Badge variant="secondary" className="bg-accent/10 text-accent">
                <span className="mr-1.5 flex h-2 w-2">
                  <span className="absolute inline-flex h-2 w-2 animate-ping rounded-full bg-accent opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
                </span>
                Live
              </Badge>
            )}
            {poll.isAnonymous && (
              <Badge variant="outline" className="text-muted-foreground">
                Anonymous
              </Badge>
            )}
          </div>
          <SharePoll pollId={poll.id} />
        </div>

        <h1 className="text-balance text-xl font-bold leading-snug text-foreground sm:text-2xl">
          {poll.question}
        </h1>

        <div className="mt-3 flex items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <Users className="h-3.5 w-3.5" />
            {poll.totalVotes} {poll.totalVotes === 1 ? "vote" : "votes"}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            {new Date(poll.createdAt).toLocaleDateString()}
          </span>
        </div>
      </div>

      {/* Voting / Results */}
      <div className="stagger-children space-y-3">
        {poll.options.map((option, index) => {
          const percentage = poll.totalVotes > 0
            ? Math.round((option.votes / poll.totalVotes) * 100)
            : 0
          const isLeading = option.votes === maxVotes && option.votes > 0
          const colorClass = BAR_COLORS[index % BAR_COLORS.length]

          if (showResults) {
            return (
              <div
                key={option.id}
                className={cn(
                  "relative overflow-hidden rounded-2xl border border-border bg-card p-4 transition-all duration-300",
                  isLeading && "border-primary/40 ring-1 ring-primary/20",
                  selectedOption === option.id && "border-primary"
                )}
              >
                <div
                  className={cn(
                    "absolute inset-y-0 left-0 opacity-8 transition-all duration-1000 ease-out",
                    colorClass
                  )}
                  style={{ width: `${percentage}%` }}
                />
                <div className="relative flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-medium transition-colors",
                      isLeading
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-secondary text-secondary-foreground"
                    )}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="font-medium text-foreground">{option.text}</span>
                    {selectedOption === option.id && (
                      <CheckCircle2 className="h-4 w-4 text-primary animate-scale-in" />
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-muted-foreground">
                      {option.votes} {option.votes === 1 ? "vote" : "votes"}
                    </span>
                    <span className={cn(
                      "min-w-[3ch] text-right font-bold",
                      isLeading ? "text-primary" : "text-foreground"
                    )}>
                      {percentage}%
                    </span>
                  </div>
                </div>
                <div className="relative mt-3 h-2.5 overflow-hidden rounded-full bg-secondary">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-1000 ease-out",
                      colorClass
                    )}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            )
          }

          return (
            <button
              key={option.id}
              type="button"
              disabled={isClosed}
              onClick={() => setSelectedOption(option.id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-2xl border border-border bg-card p-4 text-left transition-all duration-200 hover:border-primary/40 hover:shadow-md hover:shadow-primary/5 hover:-translate-y-0.5",
                selectedOption === option.id && "border-primary bg-primary/5 ring-1 ring-primary/20"
              )}
            >
              <div className={cn(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-medium transition-all",
                selectedOption === option.id
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-secondary text-secondary-foreground"
              )}>
                {String.fromCharCode(65 + index)}
              </div>
              <span className="font-medium text-foreground">{option.text}</span>
              {selectedOption === option.id && (
                <CheckCircle2 className="ml-auto h-5 w-5 text-primary animate-scale-in" />
              )}
            </button>
          )
        })}
      </div>

      {/* Vote Button */}
      {!showResults && !isClosed && (
        <Button
          size="lg"
          className="h-12 w-full text-base shadow-lg shadow-primary/20 animate-fade-in-up"
          disabled={!selectedOption || isVoting}
          onClick={handleVote}
        >
          {isVoting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <BarChart3 className="mr-2 h-4 w-4" />
              Submit Vote
            </>
          )}
        </Button>
      )}

      {/* Results indicator */}
      {showResults && (
        <div className="animate-fade-in rounded-xl border border-border bg-card/50 p-3 text-center text-sm text-muted-foreground">
          {hasVoted ? (
            <span className="flex items-center justify-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              You voted. Results update live every 3 seconds.
            </span>
          ) : (
            <span className="flex items-center justify-center gap-1.5">
              <Lock className="h-4 w-4" />
              This poll is closed. Showing final results.
            </span>
          )}
        </div>
      )}

      {/* Back link */}
      <div className="text-center">
        <Button variant="ghost" size="sm" asChild className="text-muted-foreground">
          <Link href="/">
            <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
            Back to Votesnap
          </Link>
        </Button>
      </div>
    </div>
  )
}

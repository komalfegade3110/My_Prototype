"use client"

import { useState } from "react"
import { Copy, Check, QrCode, Share2, Link2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { QRCode } from "@/components/qr-code"
import { toast } from "sonner"

interface SharePollProps {
  pollId: string
  trigger?: React.ReactNode
}

export function SharePoll({ pollId, trigger }: SharePollProps) {
  const [copied, setCopied] = useState(false)
  const [showQR, setShowQR] = useState(false)

  const pollUrl = typeof window !== "undefined"
    ? `${window.location.origin}/poll/${pollId}`
    : `/poll/${pollId}`

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(pollUrl)
      setCopied(true)
      toast.success("Link copied to clipboard!")
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error("Failed to copy link")
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm">
            <Share2 className="mr-1.5 h-4 w-4" />
            Share
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <Share2 className="h-5 w-5 text-primary" />
            Share this poll
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 pt-2">
          {/* Copy Link */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Poll Link</label>
            <div className="flex gap-2">
              <Input
                readOnly
                value={pollUrl}
                className="font-mono text-sm"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={copyLink}
                className="shrink-0"
              >
                {copied ? (
                  <Check className="h-4 w-4 text-accent" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
                <span className="sr-only">Copy link</span>
              </Button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={copyLink}
            >
              <Link2 className="mr-1.5 h-4 w-4" />
              {copied ? "Copied!" : "Copy Link"}
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => setShowQR(!showQR)}
            >
              <QrCode className="mr-1.5 h-4 w-4" />
              {showQR ? "Hide QR" : "Show QR"}
            </Button>
          </div>

          {/* QR Code */}
          {showQR && (
            <div className="flex flex-col items-center gap-3 rounded-lg border border-border bg-card p-6">
              <QRCode value={pollUrl} size={180} />
              <p className="text-xs text-muted-foreground">Scan to vote on this poll</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

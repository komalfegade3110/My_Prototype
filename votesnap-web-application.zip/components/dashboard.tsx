"use client"

import { useState, useEffect, useCallback } from "react"
import Link from "next/link"
import {
  BarChart3,
  Clock,
  Lock,
  Trash2,
  Users,
  ExternalLink,
  Share2,
  Loader2,
  Plus,
  Zap,
  TrendingUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { SharePoll } from "@/components/share-poll"
import { useCreatorToken } from "@/hooks/use-creator-token"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

interface PollOption {
  id: string
  text: string
  votes: number
}

interface PollData {
  id: string
  question: string
  options: PollOption[]
  createdAt: string
  closedAt: string | null
  isAnonymous: boolean
  totalVotes: number
}

export function Dashboard() {
  const creatorToken = useCreatorToken()
  const [polls, setPolls] = useState<PollData[]>([])
  const [loading, setLoading] = useState(true)
  const [closingId, setClosingId] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const fetchPolls = useCallback(async () => {
    if (!creatorToken) return
    try {
      const res = await fetch(`/api/polls?creatorToken=${creatorToken}`)
      if (res.ok) {
        const data = await res.json()
        setPolls(data)
      }
    } catch {
      toast.error("Failed to load polls")
    } finally {
      setLoading(false)
    }
  }, [creatorToken])

  useEffect(() => {
    fetchPolls()
  }, [fetchPolls])

  useEffect(() => {
    if (!creatorToken) return
    const interval = setInterval(fetchPolls, 5000)
    return () => clearInterval(interval)
  }, [fetchPolls, creatorToken])

  const closePoll = async (pollId: string) => {
    setClosingId(pollId)
    try {
      const res = await fetch(`/api/polls/${pollId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ creatorToken }),
      })
      if (res.ok) {
        toast.success("Poll closed")
        fetchPolls()
      } else {
        const data = await res.json()
        toast.error(data.error || "Failed to close poll")
      }
    } catch {
      toast.error("Something went wrong")
    } finally {
      setClosingId(null)
    }
  }

  const deletePoll = async (pollId: string) => {
    setDeletingId(pollId)
    try {
      const res = await fetch(`/api/polls/${pollId}?creatorToken=${creatorToken}`, {
        method: "DELETE",
      })
      if (res.ok) {
        toast.success("Poll deleted")
        setPolls(polls.filter((p) => p.id !== pollId))
      } else {
        const data = await res.json()
        toast.error(data.error || "Failed to delete poll")
      }
    } catch {
      toast.error("Something went wrong")
    } finally {
      setDeletingId(null)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="relative">
          <div className="h-12 w-12 rounded-full border-2 border-secondary" />
          <div className="absolute inset-0 h-12 w-12 animate-spin rounded-full border-2 border-transparent border-t-primary" />
        </div>
        <p className="mt-4 text-sm text-muted-foreground">Loading your polls...</p>
      </div>
    )
  }

  if (polls.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in-up">
        <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary/10">
          <BarChart3 className="h-9 w-9 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-foreground">No polls yet</h2>
        <p className="mt-2 max-w-sm text-muted-foreground">
          Create your first poll and start collecting votes from your group.
        </p>
        <Button asChild className="mt-6 shadow-lg shadow-primary/20">
          <Link href="/create">
            <Plus className="mr-1.5 h-4 w-4" />
            Create Your First Poll
          </Link>
        </Button>
      </div>
    )
  }

  const totalPolls = polls.length
  const totalVotes = polls.reduce((sum, p) => sum + p.totalVotes, 0)
  const activePolls = polls.filter((p) => !p.closedAt).length

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between animate-fade-in-up">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Your Polls</h1>
          <p className="text-sm text-muted-foreground">Manage and monitor all your polls</p>
        </div>
        <Button asChild className="shadow-sm shadow-primary/20">
          <Link href="/create">
            <Plus className="mr-1.5 h-4 w-4" />
            New Poll
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="stagger-children grid grid-cols-3 gap-4">
        {[
          { label: "Total Polls", value: totalPolls, icon: Zap, color: "text-primary" },
          { label: "Total Votes", value: totalVotes, icon: Users, color: "text-accent" },
          { label: "Active", value: activePolls, icon: TrendingUp, color: "text-primary" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="group rounded-2xl border border-border bg-card p-4 shadow-sm transition-all duration-300 hover:shadow-md hover:shadow-primary/5 hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-2 text-muted-foreground">
              <stat.icon className={cn("h-4 w-4", stat.color)} />
              <span className="text-xs font-medium">{stat.label}</span>
            </div>
            <p className="mt-1.5 text-2xl font-bold text-foreground">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Poll List */}
      <div className="stagger-children space-y-4">
        {polls.map((poll) => {
          const isClosed = !!poll.closedAt
          const leadingOption = poll.options.reduce(
            (max, o) => (o.votes > max.votes ? o : max),
            poll.options[0]
          )

          return (
            <div
              key={poll.id}
              className="group rounded-2xl border border-border bg-card p-5 shadow-sm transition-all duration-300 hover:border-border/80 hover:shadow-md"
            >
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="mb-2 flex flex-wrap items-center gap-2">
                    {isClosed ? (
                      <Badge variant="secondary" className="bg-destructive/10 text-destructive">
                        <Lock className="mr-1 h-3 w-3" />
                        Closed
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-accent/10 text-accent">
                        <span className="mr-1.5 flex h-2 w-2">
                          <span className="absolute inline-flex h-2 w-2 animate-ping rounded-full bg-accent opacity-75" />
                          <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
                        </span>
                        Live
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {new Date(poll.createdAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  <Link
                    href={`/poll/${poll.id}`}
                    className="text-lg font-semibold leading-snug text-foreground transition-colors hover:text-primary"
                  >
                    {poll.question}
                  </Link>
                  <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" />
                      {poll.totalVotes} votes
                    </span>
                    <span className="flex items-center gap-1">
                      <BarChart3 className="h-3.5 w-3.5" />
                      {poll.options.length} options
                    </span>
                    {poll.totalVotes > 0 && (
                      <span className="text-xs">
                        Leading:{" "}
                        <span className="font-medium text-foreground">{leadingOption.text}</span>
                      </span>
                    )}
                  </div>

                  {/* Mini progress bars */}
                  <div className="mt-3 space-y-1.5">
                    {poll.options.slice(0, 3).map((option) => {
                      const pct = poll.totalVotes > 0
                        ? Math.round((option.votes / poll.totalVotes) * 100)
                        : 0
                      return (
                        <div key={option.id} className="flex items-center gap-2">
                          <span className="w-20 truncate text-xs text-muted-foreground">
                            {option.text}
                          </span>
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                            <div
                              className="h-full rounded-full bg-primary transition-all duration-700"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="w-8 text-right text-xs font-medium text-muted-foreground">
                            {pct}%
                          </span>
                        </div>
                      )
                    })}
                    {poll.options.length > 3 && (
                      <p className="text-xs text-muted-foreground">
                        +{poll.options.length - 3} more options
                      </p>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex shrink-0 items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    asChild
                    className="h-8 w-8 text-muted-foreground hover:text-foreground"
                  >
                    <Link href={`/poll/${poll.id}`}>
                      <ExternalLink className="h-4 w-4" />
                      <span className="sr-only">View poll</span>
                    </Link>
                  </Button>

                  <SharePoll
                    pollId={poll.id}
                    trigger={
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-foreground"
                      >
                        <Share2 className="h-4 w-4" />
                        <span className="sr-only">Share poll</span>
                      </Button>
                    }
                  />

                  {!isClosed && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => closePoll(poll.id)}
                      disabled={closingId === poll.id}
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                    >
                      {closingId === poll.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Lock className="h-4 w-4" />
                      )}
                      <span className="sr-only">Close poll</span>
                    </Button>
                  )}

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete poll</span>
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-foreground">Delete this poll?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently delete the poll and all its votes.
                          This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deletePoll(poll.id)}
                          disabled={deletingId === poll.id}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          {deletingId === poll.id ? "Deleting..." : "Delete"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

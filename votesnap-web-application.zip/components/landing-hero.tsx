"use client"

import Link from "next/link"
import {
  Zap,
  Users,
  BarChart3,
  Share2,
  ArrowRight,
  Lock,
  QrCode,
  Target,
  RefreshCw,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  ArrowUpRight,
  Timer,
  Layers,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  FloatingPollCard,
  FloatingVoteCard,
  FloatingQRCard,
  AnimatedStats,
  SprintBoardIllustration,
  RetroIllustration,
} from "@/components/animated-illustrations"

const features = [
  {
    icon: Zap,
    title: "Instant Polls",
    description: "Create a poll in seconds. No signup, no friction.",
  },
  {
    icon: Users,
    title: "Anonymous Voting",
    description: "Everyone votes honestly. Anonymous by default.",
  },
  {
    icon: BarChart3,
    title: "Live Results",
    description: "Watch votes animate in with real-time progress bars.",
  },
  {
    icon: Share2,
    title: "Easy Sharing",
    description: "Share via link or QR code. One tap to share.",
  },
  {
    icon: Lock,
    title: "Fair Voting",
    description: "One vote per person. Enforced automatically.",
  },
  {
    icon: QrCode,
    title: "QR Generator",
    description: "Scan and vote from any device, instantly.",
  },
]

const agileUseCases = [
  {
    icon: Target,
    title: "Sprint Planning",
    description: "Vote on sprint priorities and story points as a team. No more endless debates about what to work on next.",
    tag: "Planning",
  },
  {
    icon: RefreshCw,
    title: "Retrospectives",
    description: "Gather anonymous feedback on what went well and what needs improvement. Honest insights every sprint.",
    tag: "Feedback",
  },
  {
    icon: MessageSquare,
    title: "Daily Standups",
    description: "Quick pulse checks and blocker votes to keep standup focused and time-boxed.",
    tag: "Daily",
  },
  {
    icon: Layers,
    title: "Backlog Grooming",
    description: "Prioritize user stories with team-wide voting. Let data drive your product decisions.",
    tag: "Prioritize",
  },
]

const aiSuggestions = [
  "What should our team focus on this sprint?",
  "Which feature should we ship first?",
  "Where should we hold the study session?",
  "Best time for our group meeting?",
  "Which project topic should we pick?",
]

export function LandingHero() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background gradient orbs */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -left-32 -top-32 h-96 w-96 rounded-full bg-primary/6 blur-3xl animate-pulse-glow" />
          <div className="absolute -right-32 top-1/4 h-80 w-80 rounded-full bg-accent/5 blur-3xl animate-pulse-glow" style={{ animationDelay: "1.5s" }} />
          <div className="absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-primary/4 blur-3xl animate-pulse-glow" style={{ animationDelay: "3s" }} />
        </div>

        <div className="relative mx-auto flex max-w-6xl flex-col items-center px-4 pb-24 pt-20 lg:flex-row lg:items-center lg:gap-16 lg:pb-32 lg:pt-28">
          {/* Left: text */}
          <div className="flex-1 text-center lg:text-left">
            <div className="animate-fade-in-up mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/80 px-4 py-1.5 text-sm text-muted-foreground shadow-sm backdrop-blur-sm">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              <span>AI-powered poll suggestions</span>
              <ArrowUpRight className="h-3 w-3" />
            </div>

            <h1 className="animate-fade-in-up max-w-2xl text-balance text-4xl font-bold leading-[1.1] tracking-tight text-foreground sm:text-5xl lg:text-6xl" style={{ animationDelay: "100ms" }}>
              Snap decisions,{" "}
              <span className="relative inline-block">
                <span className="relative z-10 text-primary">real-time results</span>
                <span className="absolute -bottom-1 left-0 right-0 h-3 bg-primary/10 rounded-full" />
              </span>
            </h1>

            <p className="animate-fade-in-up mt-6 max-w-lg text-pretty text-lg leading-relaxed text-muted-foreground lg:text-xl" style={{ animationDelay: "200ms" }}>
              Create instant polls and get live results without any login. Built for agile teams and college students who need quick group decisions.
            </p>

            <div className="animate-fade-in-up mt-10 flex flex-col items-center gap-3 sm:flex-row lg:justify-start" style={{ animationDelay: "300ms" }}>
              <Button size="lg" asChild className="h-12 px-8 text-base shadow-lg shadow-primary/20">
                <Link href="/create">
                  Create a Poll
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild className="h-12 px-8 text-base">
                <Link href="/dashboard">
                  View Dashboard
                </Link>
              </Button>
            </div>

            <div className="animate-fade-in-up mt-12" style={{ animationDelay: "500ms" }}>
              <AnimatedStats />
            </div>
          </div>

          {/* Right: floating cards */}
          <div className="relative mt-16 flex flex-1 items-center justify-center lg:mt-0">
            <div className="relative h-[380px] w-[340px]">
              {/* Main card */}
              <div className="absolute left-0 top-8">
                <FloatingPollCard />
              </div>
              {/* Vote card */}
              <div className="absolute -right-4 top-0">
                <FloatingVoteCard />
              </div>
              {/* QR card */}
              <div className="absolute bottom-0 right-4">
                <FloatingQRCard />
              </div>
              {/* Decorative dots */}
              <div className="absolute -left-8 top-1/2 h-20 w-20 opacity-20">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 16 }).map((_, i) => (
                    <div key={i} className="h-1.5 w-1.5 rounded-full bg-primary" />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Suggestions Marquee */}
      <section className="border-y border-border bg-card/30 py-4 overflow-hidden">
        <div className="flex animate-marquee items-center gap-6 whitespace-nowrap">
          {[...aiSuggestions, ...aiSuggestions].map((suggestion, i) => (
            <div key={i} className="flex shrink-0 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-primary" />
              {suggestion}
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-16 text-center">
            <div className="animate-fade-in-up mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
              <CheckCircle2 className="h-3 w-3 text-accent" />
              Core Features
            </div>
            <h2 className="animate-fade-in-up text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl" style={{ animationDelay: "100ms" }}>
              Everything you need for quick polls
            </h2>
            <p className="animate-fade-in-up mt-4 text-lg text-muted-foreground" style={{ animationDelay: "200ms" }}>
              Simple, fast, and built for how teams actually work.
            </p>
          </div>

          <div className="stagger-children grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group relative rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-1"
              >
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/15">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mb-2 font-semibold text-foreground">{feature.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Agile Methodologies Section */}
      <section className="border-t border-border bg-card/30 py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-16 flex flex-col items-center gap-12 lg:flex-row lg:items-start lg:gap-20">
            {/* Left: heading & illustrations */}
            <div className="flex-1">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
                <Target className="h-3 w-3 text-primary" />
                Agile Workflows
              </div>
              <h2 className="mb-4 text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Built for agile teams
              </h2>
              <p className="mb-10 max-w-md text-lg leading-relaxed text-muted-foreground">
                From sprint planning to retros, Votesnap fits naturally into your agile workflow. Make every ceremony faster and more democratic.
              </p>

              {/* Illustration cards */}
              <div className="flex flex-col gap-4 sm:flex-row">
                <SprintBoardIllustration />
                <RetroIllustration />
              </div>
            </div>

            {/* Right: use case cards */}
            <div className="w-full max-w-md space-y-4 lg:pt-12">
              {agileUseCases.map((useCase, i) => (
                <div
                  key={useCase.title}
                  className="group flex items-start gap-4 rounded-2xl border border-border bg-card p-5 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 animate-fade-in-up"
                  style={{ animationDelay: `${i * 120}ms` }}
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/15">
                    <useCase.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="mb-1 flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{useCase.title}</h3>
                      <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
                        {useCase.tag}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed text-muted-foreground">
                      {useCase.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="border-t border-border py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mb-16 text-center">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
              <Timer className="h-3 w-3 text-primary" />
              Under 10 seconds
            </div>
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              How it works
            </h2>
          </div>

          <div className="stagger-children grid gap-8 sm:grid-cols-3">
            {[
              {
                step: "01",
                title: "Create",
                description: "Type your question and add options. AI can suggest ideas too.",
                icon: Sparkles,
              },
              {
                step: "02",
                title: "Share",
                description: "Copy the link or show the QR code. Share anywhere in one tap.",
                icon: Share2,
              },
              {
                step: "03",
                title: "Decide",
                description: "Watch votes come in live. Make your decision with real data.",
                icon: BarChart3,
              },
            ].map((item) => (
              <div key={item.step} className="group relative text-center">
                <div className="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-2xl font-bold text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:shadow-lg group-hover:shadow-primary/20">
                  <item.icon className="h-6 w-6" />
                </div>
                <div className="mb-1 text-xs font-medium text-primary">Step {item.step}</div>
                <h3 className="mb-2 text-xl font-bold text-foreground">{item.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border py-24">
        <div className="mx-auto max-w-6xl px-4">
          <div className="relative overflow-hidden rounded-3xl bg-primary/5 p-12 text-center lg:p-20">
            {/* Background pattern */}
            <div className="pointer-events-none absolute inset-0">
              <div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-primary/10 blur-3xl" />
              <div className="absolute -bottom-8 -left-8 h-36 w-36 rounded-full bg-accent/10 blur-3xl" />
            </div>

            <div className="relative">
              <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Ready to make a decision?
              </h2>
              <p className="mx-auto mt-4 max-w-md text-lg text-muted-foreground">
                Create your first poll in under 10 seconds. No signup. No friction. Just decisions.
              </p>
              <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
                <Button size="lg" asChild className="h-13 px-10 text-base shadow-lg shadow-primary/20">
                  <Link href="/create">
                    Get Started Free
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild className="h-13 px-10 text-base">
                  <Link href="/dashboard">
                    View Dashboard
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary shadow-sm">
              <Zap className="h-3.5 w-3.5 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold text-foreground">Votesnap</span>
          </div>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <Link href="/create" className="transition-colors hover:text-foreground">Create Poll</Link>
            <Link href="/dashboard" className="transition-colors hover:text-foreground">Dashboard</Link>
            <Link href="/settings" className="transition-colors hover:text-foreground">Settings</Link>
          </div>
          <p className="text-sm text-muted-foreground">
            Built for students & agile teams.
          </p>
        </div>
      </footer>
    </div>
  )
}

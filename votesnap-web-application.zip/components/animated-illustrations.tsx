"use client"

export function FloatingPollCard() {
  return (
    <div className="animate-float relative">
      <div className="rounded-2xl border border-border bg-card p-5 shadow-xl">
        <div className="mb-3 flex items-center gap-2">
          <div className="h-2.5 w-2.5 rounded-full bg-accent" />
          <span className="text-xs font-medium text-muted-foreground">Live Poll</span>
        </div>
        <div className="mb-4 h-3 w-36 rounded-full bg-foreground/10" />
        {/* Animated progress bars */}
        <div className="space-y-2.5">
          <div className="flex items-center gap-2">
            <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary transition-all duration-1000"
                style={{ width: "72%", animation: "fade-in 1s ease-out 0.3s both" }}
              />
            </div>
            <span className="text-xs font-bold text-foreground">72%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-accent transition-all duration-1000"
                style={{ width: "28%", animation: "fade-in 1s ease-out 0.5s both" }}
              />
            </div>
            <span className="text-xs font-bold text-foreground">28%</span>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <div className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
          47 votes
        </div>
      </div>
    </div>
  )
}

export function FloatingVoteCard() {
  return (
    <div className="animate-float-delayed relative">
      <div className="rounded-2xl border border-primary/20 bg-card p-4 shadow-lg ring-1 ring-primary/10">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-5 w-5 items-center justify-center rounded-md bg-primary text-[10px] font-bold text-primary-foreground">
            A
          </div>
          <span className="text-xs font-medium text-foreground">Study at the library</span>
        </div>
        <div className="flex items-center gap-1.5">
          <svg className="h-3.5 w-3.5 text-primary" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
          <span className="text-xs text-primary font-medium">Vote submitted</span>
        </div>
      </div>
    </div>
  )
}

export function FloatingQRCard() {
  return (
    <div className="animate-float relative" style={{ animationDelay: "2s" }}>
      <div className="rounded-2xl border border-border bg-card p-4 shadow-lg">
        <div className="mb-2 text-center text-xs font-medium text-muted-foreground">Scan to vote</div>
        {/* Mini QR pattern */}
        <div className="mx-auto grid h-16 w-16 grid-cols-7 gap-px">
          {Array.from({ length: 49 }).map((_, i) => {
            const row = Math.floor(i / 7)
            const col = i % 7
            const isFinder = (row < 3 && col < 3) || (row < 3 && col > 3) || (row > 3 && col < 3)
            const isRandom = Math.sin(i * 7.3) > 0.1
            return (
              <div
                key={i}
                className={`rounded-[1px] ${isFinder || isRandom ? "bg-foreground" : "bg-transparent"}`}
              />
            )
          })}
        </div>
      </div>
    </div>
  )
}

export function AnimatedStats() {
  return (
    <div className="flex items-center gap-6">
      {[
        { value: "0s", label: "Signup time", color: "text-primary" },
        { value: "100%", label: "Anonymous", color: "text-accent" },
        { value: "Live", label: "Results", color: "text-primary" },
      ].map((stat, i) => (
        <div
          key={stat.label}
          className="flex flex-col items-center animate-fade-in-up"
          style={{ animationDelay: `${600 + i * 100}ms` }}
        >
          <span className={`text-3xl font-bold ${stat.color}`}>{stat.value}</span>
          <span className="text-sm text-muted-foreground">{stat.label}</span>
        </div>
      ))}
    </div>
  )
}

export function SprintBoardIllustration() {
  return (
    <div className="animate-scale-in rounded-2xl border border-border bg-card p-5 shadow-xl" style={{ animationDelay: "0.2s" }}>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold text-foreground">Sprint Board</span>
        <span className="rounded-full bg-accent/10 px-2 py-0.5 text-[10px] font-medium text-accent">Sprint 4</span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {/* To Do */}
        <div className="space-y-1.5">
          <div className="text-[10px] font-medium text-muted-foreground">To Do</div>
          <div className="rounded-lg bg-secondary/60 p-2">
            <div className="h-1.5 w-12 rounded-full bg-chart-3/60" />
            <div className="mt-1 h-1.5 w-8 rounded-full bg-muted-foreground/20" />
          </div>
          <div className="rounded-lg bg-secondary/60 p-2">
            <div className="h-1.5 w-10 rounded-full bg-primary/40" />
            <div className="mt-1 h-1.5 w-6 rounded-full bg-muted-foreground/20" />
          </div>
        </div>
        {/* In Progress */}
        <div className="space-y-1.5">
          <div className="text-[10px] font-medium text-muted-foreground">Doing</div>
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-2">
            <div className="h-1.5 w-10 rounded-full bg-primary/60" />
            <div className="mt-1 h-1.5 w-7 rounded-full bg-muted-foreground/20" />
          </div>
        </div>
        {/* Done */}
        <div className="space-y-1.5">
          <div className="text-[10px] font-medium text-muted-foreground">Done</div>
          <div className="rounded-lg bg-accent/10 p-2">
            <div className="h-1.5 w-11 rounded-full bg-accent/60" />
            <div className="mt-1 h-1.5 w-5 rounded-full bg-muted-foreground/20" />
          </div>
          <div className="rounded-lg bg-accent/10 p-2">
            <div className="h-1.5 w-9 rounded-full bg-accent/60" />
            <div className="mt-1 h-1.5 w-7 rounded-full bg-muted-foreground/20" />
          </div>
        </div>
      </div>
    </div>
  )
}

export function RetroIllustration() {
  return (
    <div className="animate-scale-in rounded-2xl border border-border bg-card p-5 shadow-xl" style={{ animationDelay: "0.4s" }}>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-semibold text-foreground">Retrospective</span>
        <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">Live</span>
      </div>
      <div className="space-y-2">
        {[
          { emoji: "+", label: "Went well", count: 12, color: "bg-accent" },
          { emoji: "-", label: "Improve", count: 8, color: "bg-chart-3" },
          { emoji: "?", label: "Ideas", count: 5, color: "bg-primary" },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-2">
            <span className={`flex h-5 w-5 items-center justify-center rounded-md ${item.color}/10 text-[10px] font-bold ${item.color === "bg-accent" ? "text-accent" : item.color === "bg-chart-3" ? "text-chart-3" : "text-primary"}`}>
              {item.emoji}
            </span>
            <span className="flex-1 text-xs text-muted-foreground">{item.label}</span>
            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-secondary">
              <div className={`h-full rounded-full ${item.color}`} style={{ width: `${(item.count / 12) * 100}%` }} />
            </div>
            <span className="text-[10px] font-medium text-foreground">{item.count}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

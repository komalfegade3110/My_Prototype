"use client"

import { useEffect, useRef } from "react"

interface QRCodeProps {
  value: string
  size?: number
}

export function QRCode({ value, size = 200 }: QRCodeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Simple QR-like visual using a deterministic pattern from the URL
    const moduleCount = 21
    const moduleSize = size / moduleCount

    canvas.width = size
    canvas.height = size

    // Get computed styles for theming
    const computedStyle = getComputedStyle(document.documentElement)
    const isDark = document.documentElement.classList.contains("dark")
    const fg = isDark ? "#e8e9f0" : "#1a1b2e"
    const bg = isDark ? "#2a2b3e" : "#ffffff"

    ctx.fillStyle = bg
    ctx.fillRect(0, 0, size, size)

    // Generate a pattern from the URL string
    const hash = (str: string) => {
      let h = 0
      for (let i = 0; i < str.length; i++) {
        h = ((h << 5) - h + str.charCodeAt(i)) | 0
      }
      return Math.abs(h)
    }

    const seed = hash(value)

    // Draw finder patterns (the three squares in corners)
    const drawFinder = (x: number, y: number) => {
      ctx.fillStyle = fg
      ctx.fillRect(x * moduleSize, y * moduleSize, 7 * moduleSize, 7 * moduleSize)
      ctx.fillStyle = bg
      ctx.fillRect((x + 1) * moduleSize, (y + 1) * moduleSize, 5 * moduleSize, 5 * moduleSize)
      ctx.fillStyle = fg
      ctx.fillRect((x + 2) * moduleSize, (y + 2) * moduleSize, 3 * moduleSize, 3 * moduleSize)
    }

    drawFinder(0, 0)
    drawFinder(moduleCount - 7, 0)
    drawFinder(0, moduleCount - 7)

    // Draw data modules
    ctx.fillStyle = fg
    for (let row = 0; row < moduleCount; row++) {
      for (let col = 0; col < moduleCount; col++) {
        // Skip finder pattern areas
        if (
          (row < 8 && col < 8) ||
          (row < 8 && col >= moduleCount - 8) ||
          (row >= moduleCount - 8 && col < 8)
        ) continue

        const val = hash(value + row.toString() + col.toString() + seed.toString())
        if (val % 3 !== 0) {
          ctx.fillRect(
            col * moduleSize + 0.5,
            row * moduleSize + 0.5,
            moduleSize - 1,
            moduleSize - 1
          )
        }
      }
    }
  }, [value, size])

  return (
    <canvas
      ref={canvasRef}
      className="rounded-lg"
      style={{ width: size, height: size }}
    />
  )
}

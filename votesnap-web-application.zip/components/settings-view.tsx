"use client"

import { useTheme } from "next-themes"
import { useEffect, useState } from "react"
import {
  Sun,
  Moon,
  Monitor,
  Settings,
  Palette,
  Info,
  Zap,
  Shield,
  ExternalLink,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import Link from "next/link"

const themeOptions = [
  {
    value: "light",
    label: "Light",
    icon: Sun,
    description: "Clean and bright for daytime use",
    preview: "bg-[#f8f9fb] border-[#e0e2ea]",
    previewDot: "bg-[#4a3ef5]",
  },
  {
    value: "dark",
    label: "Dark",
    icon: Moon,
    description: "Easy on the eyes for night sessions",
    preview: "bg-[#1e1f34] border-[#3a3b52]",
    previewDot: "bg-[#6366f1]",
  },
  {
    value: "system",
    label: "System",
    icon: Monitor,
    description: "Matches your device's current setting",
    preview: "bg-gradient-to-r from-[#f8f9fb] to-[#1e1f34] border-[#e0e2ea]",
    previewDot: "bg-gradient-to-r from-[#4a3ef5] to-[#6366f1]",
  },
]

export function SettingsView() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="mx-auto max-w-2xl animate-pulse space-y-6">
        <div className="h-8 w-32 rounded-lg bg-secondary" />
        <div className="h-64 rounded-2xl bg-secondary" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      {/* Header */}
      <div className="animate-fade-in-up">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
            <Settings className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-foreground">Settings</h1>
            <p className="text-sm text-muted-foreground">Personalize your Votesnap experience</p>
          </div>
        </div>
      </div>

      {/* Appearance Section */}
      <div className="animate-fade-in-up rounded-2xl border border-border bg-card p-6 shadow-sm" style={{ animationDelay: "100ms" }}>
        <div className="mb-6 flex items-center gap-2.5">
          <Palette className="h-4.5 w-4.5 text-primary" />
          <h2 className="font-semibold text-foreground">Appearance</h2>
        </div>

        <div className="space-y-3">
          {themeOptions.map((option) => {
            const isActive = theme === option.value
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => setTheme(option.value)}
                className={cn(
                  "flex w-full items-center gap-4 rounded-xl border p-4 text-left transition-all duration-200",
                  isActive
                    ? "border-primary bg-primary/5 ring-1 ring-primary/20 shadow-sm"
                    : "border-border bg-background hover:border-primary/20 hover:shadow-sm"
                )}
              >
                {/* Preview swatch */}
                <div className={cn(
                  "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border-2 transition-all",
                  option.preview
                )}>
                  <div className={cn("h-3 w-3 rounded-full", option.previewDot)} />
                </div>

                {/* Text */}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <option.icon className={cn(
                      "h-4 w-4",
                      isActive ? "text-primary" : "text-muted-foreground"
                    )} />
                    <span className="font-medium text-foreground">{option.label}</span>
                    {isActive && (
                      <Badge variant="secondary" className="bg-primary/10 text-primary text-xs px-1.5 py-0">
                        Active
                      </Badge>
                    )}
                  </div>
                  <p className="mt-0.5 text-sm text-muted-foreground">{option.description}</p>
                </div>

                {/* Radio dot */}
                <div className={cn(
                  "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-all",
                  isActive ? "border-primary" : "border-muted-foreground/30"
                )}>
                  {isActive && (
                    <div className="h-2.5 w-2.5 rounded-full bg-primary animate-scale-in" />
                  )}
                </div>
              </button>
            )
          })}
        </div>

        <div className="mt-4 rounded-xl bg-secondary/50 p-3 text-sm text-muted-foreground">
          <p>
            Currently using: <span className="font-medium text-foreground">{resolvedTheme === "dark" ? "Dark" : "Light"}</span> mode
          </p>
        </div>
      </div>

      {/* About Section */}
      <div className="animate-fade-in-up rounded-2xl border border-border bg-card p-6 shadow-sm" style={{ animationDelay: "200ms" }}>
        <div className="mb-5 flex items-center gap-2.5">
          <Info className="h-4.5 w-4.5 text-primary" />
          <h2 className="font-semibold text-foreground">About Votesnap</h2>
        </div>

        <div className="space-y-4">
          <div className="flex items-start gap-4 rounded-xl bg-secondary/30 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary shadow-sm">
              <Zap className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Votesnap v1.0</h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                A modern polling platform built for agile teams and college students. Create instant polls, 
                get real-time results, and make group decisions faster than ever.
              </p>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-border p-4">
              <div className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4 text-accent" />
                <span className="font-medium text-foreground">Privacy First</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                No signup needed. Anonymous voting by default. Your data stays private.
              </p>
            </div>
            <div className="rounded-xl border border-border p-4">
              <div className="flex items-center gap-2 text-sm">
                <Zap className="h-4 w-4 text-primary" />
                <span className="font-medium text-foreground">Lightning Fast</span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Create a poll in under 10 seconds. Share it instantly via link or QR code.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Links */}
      <div className="animate-fade-in-up flex flex-wrap gap-3" style={{ animationDelay: "300ms" }}>
        <Button asChild variant="outline">
          <Link href="/create">
            <Zap className="mr-1.5 h-4 w-4" />
            Create Poll
          </Link>
        </Button>
        <Button asChild variant="outline">
          <Link href="/dashboard">
            <ExternalLink className="mr-1.5 h-4 w-4" />
            Dashboard
          </Link>
        </Button>
      </div>
    </div>
  )
}

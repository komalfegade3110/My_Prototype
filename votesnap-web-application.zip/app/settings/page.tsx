"use client"

import { Navbar } from "@/components/navbar"
import { SettingsView } from "@/components/settings-view"

export default function SettingsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-12">
        <SettingsView />
      </main>
    </div>
  )
}

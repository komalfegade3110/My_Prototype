import { NextRequest, NextResponse } from "next/server"
import { createPoll, getPollsByCreator, serializePoll } from "@/lib/poll-store"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { question, options, creatorToken, isAnonymous } = body

    if (!question || !options || options.length < 2 || !creatorToken) {
      return NextResponse.json(
        { error: "Question, at least 2 options, and creator token are required" },
        { status: 400 }
      )
    }

    const filteredOptions = options.filter((o: string) => o.trim() !== "")
    if (filteredOptions.length < 2) {
      return NextResponse.json(
        { error: "At least 2 non-empty options are required" },
        { status: 400 }
      )
    }

    const poll = createPoll(question, filteredOptions, creatorToken, isAnonymous ?? true)
    return NextResponse.json(serializePoll(poll), { status: 201 })
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const creatorToken = searchParams.get("creatorToken")

  if (!creatorToken) {
    return NextResponse.json({ error: "Creator token is required" }, { status: 400 })
  }

  const polls = getPollsByCreator(creatorToken)
  return NextResponse.json(polls.map((p) => serializePoll(p)))
}

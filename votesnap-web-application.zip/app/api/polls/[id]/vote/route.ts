import { NextRequest, NextResponse } from "next/server"
import { vote, getPoll, serializePoll } from "@/lib/poll-store"

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  try {
    const body = await request.json()
    const { optionId, voterToken } = body

    if (!optionId || !voterToken) {
      return NextResponse.json(
        { error: "Option ID and voter token are required" },
        { status: 400 }
      )
    }

    const result = vote(id, optionId, voterToken)
    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 400 })
    }

    const poll = getPoll(id)
    if (!poll) {
      return NextResponse.json({ error: "Poll not found" }, { status: 404 })
    }

    return NextResponse.json(serializePoll(poll, voterToken))
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}

import { NextRequest, NextResponse } from "next/server"
import { getPoll, closePoll, deletePoll, serializePoll } from "@/lib/poll-store"

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const voterToken = new URL(request.url).searchParams.get("voterToken") || undefined
  const poll = getPoll(id)

  if (!poll) {
    return NextResponse.json({ error: "Poll not found" }, { status: 404 })
  }

  return NextResponse.json(serializePoll(poll, voterToken))
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  try {
    const body = await request.json()
    const { creatorToken } = body

    if (!creatorToken) {
      return NextResponse.json({ error: "Creator token required" }, { status: 400 })
    }

    const result = closePoll(id, creatorToken)
    if (!result.success) {
      return NextResponse.json({ error: result.message }, { status: 400 })
    }

    return NextResponse.json({ message: result.message })
  } catch {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const creatorToken = new URL(request.url).searchParams.get("creatorToken")

  if (!creatorToken) {
    return NextResponse.json({ error: "Creator token required" }, { status: 400 })
  }

  const result = deletePoll(id, creatorToken)
  if (!result.success) {
    return NextResponse.json({ error: result.message }, { status: 400 })
  }

  return NextResponse.json({ message: result.message })
}

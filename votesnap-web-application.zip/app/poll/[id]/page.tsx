"use client"

import { use } from "react"
import { Navbar } from "@/components/navbar"
import { PollView } from "@/components/poll-view"

export default function PollPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-12">
        <PollView pollId={id} />
      </main>
    </div>
  )
}

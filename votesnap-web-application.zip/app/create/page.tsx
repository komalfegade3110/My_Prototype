"use client"

import { Navbar } from "@/components/navbar"
import { CreatePollForm } from "@/components/create-poll-form"

export default function CreatePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-12">
        <CreatePollForm />
      </main>
    </div>
  )
}

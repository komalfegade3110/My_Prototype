"use client"

import { Navbar } from "@/components/navbar"
import { Dashboard } from "@/components/dashboard"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="mx-auto max-w-5xl px-4 py-12">
        <Dashboard />
      </main>
    </div>
  )
}

"use client"

import { Navbar } from "@/components/navbar"
import { LandingHero } from "@/components/landing-hero"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <LandingHero />
      </main>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"

function generateToken(): string {
  return "ct_" + Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
}

export function useCreatorToken(): string {
  const [token, setToken] = useState<string>("")

  useEffect(() => {
    const existing = localStorage.getItem("votesnap_creator_token")
    if (existing) {
      setToken(existing)
    } else {
      const newToken = generateToken()
      localStorage.setItem("votesnap_creator_token", newToken)
      setToken(newToken)
    }
  }, [])

  return token
}

export function useVoterToken(): string {
  const [token, setToken] = useState<string>("")

  useEffect(() => {
    const existing = localStorage.getItem("votesnap_voter_token")
    if (existing) {
      setToken(existing)
    } else {
      const newToken = "vt_" + Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
      localStorage.setItem("votesnap_voter_token", newToken)
      setToken(newToken)
    }
  }, [])

  return token
}

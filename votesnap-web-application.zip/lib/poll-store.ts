export interface PollOption {
  id: string
  text: string
  votes: number
}

export interface Poll {
  id: string
  question: string
  options: PollOption[]
  createdAt: string
  closedAt: string | null
  isAnonymous: boolean
  creatorToken: string
  voters: Set<string>
}

export interface PollResponse {
  id: string
  question: string
  options: PollOption[]
  createdAt: string
  closedAt: string | null
  isAnonymous: boolean
  totalVotes: number
}

const polls = new Map<string, Poll>()

function generateId(): string {
  return Math.random().toString(36).substring(2, 10)
}

export function createPoll(
  question: string,
  options: string[],
  creatorToken: string,
  isAnonymous: boolean = true
): Poll {
  const id = generateId()
  const poll: Poll = {
    id,
    question,
    options: options.map((text) => ({
      id: generateId(),
      text,
      votes: 0,
    })),
    createdAt: new Date().toISOString(),
    closedAt: null,
    isAnonymous,
    creatorToken,
    voters: new Set<string>(),
  }
  polls.set(id, poll)
  return poll
}

export function getPoll(id: string): Poll | undefined {
  return polls.get(id)
}

export function getPollsByCreator(creatorToken: string): Poll[] {
  const result: Poll[] = []
  polls.forEach((poll) => {
    if (poll.creatorToken === creatorToken) {
      result.push(poll)
    }
  })
  return result.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )
}

export function vote(
  pollId: string,
  optionId: string,
  voterToken: string
): { success: boolean; message: string } {
  const poll = polls.get(pollId)
  if (!poll) return { success: false, message: "Poll not found" }
  if (poll.closedAt) return { success: false, message: "Poll is closed" }
  if (poll.voters.has(voterToken))
    return { success: false, message: "You have already voted" }

  const option = poll.options.find((o) => o.id === optionId)
  if (!option) return { success: false, message: "Option not found" }

  option.votes++
  poll.voters.add(voterToken)
  return { success: true, message: "Vote recorded" }
}

export function closePoll(
  pollId: string,
  creatorToken: string
): { success: boolean; message: string } {
  const poll = polls.get(pollId)
  if (!poll) return { success: false, message: "Poll not found" }
  if (poll.creatorToken !== creatorToken)
    return { success: false, message: "Unauthorized" }
  poll.closedAt = new Date().toISOString()
  return { success: true, message: "Poll closed" }
}

export function deletePoll(
  pollId: string,
  creatorToken: string
): { success: boolean; message: string } {
  const poll = polls.get(pollId)
  if (!poll) return { success: false, message: "Poll not found" }
  if (poll.creatorToken !== creatorToken)
    return { success: false, message: "Unauthorized" }
  polls.delete(pollId)
  return { success: true, message: "Poll deleted" }
}

export function serializePoll(poll: Poll, voterToken?: string): PollResponse & { hasVoted?: boolean } {
  return {
    id: poll.id,
    question: poll.question,
    options: poll.options.map((o) => ({ ...o })),
    createdAt: poll.createdAt,
    closedAt: poll.closedAt,
    isAnonymous: poll.isAnonymous,
    totalVotes: poll.options.reduce((sum, o) => sum + o.votes, 0),
    hasVoted: voterToken ? poll.voters.has(voterToken) : undefined,
  }
}
